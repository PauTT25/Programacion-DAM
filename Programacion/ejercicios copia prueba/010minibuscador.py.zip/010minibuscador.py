cadena = "Esto es una cadena de prueba"
objetivo = "manzana"

if objetivo in cadena:
    print("Efectivamente esta")
else:
    print("No esta")
    
    
